/*
Abel Salazar
January 9th, 2014
Gaming interpolation
using temperature conversion degree fahrenheit to celsius
*/

//system libraries
#include <cstdlib>
#include <iostream>
#include <iomanip>

//global constant

//function prototype

//execution begins here
using namespace std;

int main()
{
    //declare and initialize variables
    short f, f1=32, f2=212, c, cIntrp, cEq, c1=0, c2=100;
    //input the temperature f to convert to c
    cout << "What degree fahrenheit temperature would you like to convert to c"
         << endl;
    cin >> f;
    //calculate 2 different ways
    cEq=5.0/9*(f-32);
    cIntrp = c1 + (c2 - c1) * (f - f1) / (static_cast<float>(f2 - f1));
    //the resulting temp is
    cout << "The C by Equation = " << cEq <<endl;
    cout << "The C by Interpolation = " << cIntrp <<endl;
    //exit stage right
    
    system("PAUSE");
    return EXIT_SUCCESS;
}
