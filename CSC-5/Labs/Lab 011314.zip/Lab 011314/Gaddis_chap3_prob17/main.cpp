/* 
 * File:   main.cpp
 * Author: Abel Salazar
 * Gaddis Chapter 3 problem 17
 * Created on January 13, 2014, 11:33 AM
 */

//system libraries
#include <iostream>
#include <cmath>
#include <iomanip>

using namespace std;

//global constant

//prototype function

//execution starts here
int main(int argc, char** argv) {
    //variables
    float payment, rate, loan, months, temp;
    //output instructions
    cout <<"Input the amount in dollars you are taking out in your loan"<<endl;
    cin >> loan;
    cout << "Enter your interest rate percentage" <<endl;
    cin >> rate;
    cout << "Input the life of the loan in months" <<endl;
    cin >> months;
    temp = pow(1 + rate,months);
    payment = ((loan * temp) / (temp - 1) * 12);
    cout << "Your payment comes out to " << payment << " dollars " << endl <<
            "each month for the next " << months << " months" <<endl;
    
    return 0;
}

