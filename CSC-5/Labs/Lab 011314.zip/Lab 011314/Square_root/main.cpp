/* 
 * File:   Savitch version 7, chapter 2 - problem 12
 * Author: Abel Salazar
 * Created on January 13, 2014, 11:09 AM
 * Calculating square root
 */

//system libraries
#include <iostream>
#include <cmath>

using namespace std;

//global constants

//prototype functions

//execution begins here
int main(int argc, char** argv) {
    //declare variables
    float x, r, guess;
    //input the value to find the square root of
    cout << "What number do you wish to find the square root of?" <<endl;
    cin >> x;
    
    guess = x/2;
    r = x/guess;
    guess =(guess + r)/2;
    
    //output approximation
    cout << "The first approximations is " << guess <<endl;
    r = x/guess;
    guess =(guess + r)/2;
    //output approximation 2
    cout << "The second approximations is " << guess <<endl;
    r = x/guess;
    guess =(guess + r)/2;
    //output approximation 3
    cout << "The third approximations is " << guess <<endl;
    
    cout << "The exact square root is " << sqrt(x) <<endl;
    //exit stage right
    return 0;
}

