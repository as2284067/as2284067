/* 
 * File:   Truth Table
 * Author: Abel Salazar
 * Created on January 13, 2014, 10:34 AM
 */

//system libraries
#include <cstdlib>
#include <iostream>

//global constants

//prototype functions

//execution begins here
using namespace std;

int main(int argc, char** argv){
    //declare variables
    bool x = true, y = true;
    //output the table heading
    cout << "x  y, !x !y, x&&y, x || y, x ^ y, x ^ y ^ y, x ^ y ^ x "
            << "!(x && y) !x || !y !(x || y) " <<endl;
    //output the first row
    cout << (x ? 'T' : 'F') << " ";
    cout << (y ? 'T' : 'F') << " ";
    cout << (!x ? 'T' : 'F') << " ";
    cout << (!y ? 'T' : 'F') << " ";
    cout << (x&&y ? 'T' : 'F') << " ";
    cout << (x||y ? 'T': 'F') << " ";
    cout << (x^y ? 'T': 'F') << " ";
    cout << (x^y^y ? 'T': 'F') << " ";
    cout << (x^y^x ? 'T': 'F') << " ";
    cout << (!(x&&y) ? 'T': 'F') << " ";
    cout << (!x||!y ? 'T': 'F') << " ";
    cout << (!(x||y) ? 'T': 'F') << " ";
    cout <<endl;
    y = false;
    cout << (x ? 'T' : 'F') << " ";
    cout << (y ? 'T' : 'F') << " ";
    cout << (!x ? 'T' : 'F') << " ";
    cout << (!y ? 'T' : 'F') << " ";
    cout << (x&&y ? 'T' : 'F') << " ";
    cout << (x||y ? 'T': 'F') << " ";
    cout << (x^y ? 'T': 'F') << " ";
    cout << (x^y^y ? 'T': 'F') << " ";
    cout << (x^y^x ? 'T': 'F') << " ";
    cout << (!(x&&y) ? 'T': 'F') << " ";
    cout << (!x||!y ? 'T': 'F') << " ";
    cout << (!(x||y) ? 'T': 'F') << " ";
    cout <<endl;
    x = false, y = true;
    cout << (x ? 'T' : 'F') << " ";
    cout << (y ? 'T' : 'F') << " ";
    cout << (!x ? 'T' : 'F') << " ";
    cout << (!y ? 'T' : 'F') << " ";
    cout << (x&&y ? 'T' : 'F') << " ";
    cout << (x||y ? 'T': 'F') << " ";
    cout << (x^y ? 'T': 'F') << " ";
    cout << (x^y^y ? 'T': 'F') << " ";
    cout << (x^y^x ? 'T': 'F') << " ";
    cout << (!(x&&y) ? 'T': 'F') << " ";
    cout << (!x||!y ? 'T': 'F') << " ";
    cout << (!(x||y) ? 'T': 'F') << " ";
    cout << endl;
    x = false, y = false;
    cout << (x ? 'T' : 'F') << " ";
    cout << (y ? 'T' : 'F') << " ";
    cout << (!x ? 'T' : 'F') << " ";
    cout << (!y ? 'T' : 'F') << " ";
    cout << (x&&y ? 'T' : 'F') << " ";
    cout << (x||y ? 'T': 'F') << " ";
    cout << (x^y ? 'T': 'F') << " ";
    cout << (x^y^y ? 'T': 'F') << " ";
    cout << (x^y^x ? 'T': 'F') << " ";
    cout << (!(x&&y) ? 'T': 'F') << " ";
    cout << (!x||!y ? 'T': 'F') << " ";
    cout << (!(x||y) ? 'T': 'F') << " ";
    
    
    return 0;
}

