/*
  Abel Salazar
  January 7th, 2014
  1)Calculate distance to a star
  2)Utilize scientific notation
  */
//system libraries
#include <iostream>

//global constants
const float vc = 3.0e8;//3x10^8 meters
const float cnv_m_km = 1e-3;//conversion from meters to kilometers
const float cnv_ft_m = 3.048e-1;//conversion from feet to meters
const float cnv_mi_ft = 5.280e3;//conversion to miles from feet
const float cnv_sec_yr = 60 * 60 * 24 * 365;//conversion from seconds to years

//function prototypes

//execution begins here
using namespace std;



int main()
{
    //declare variables
    float DLtYrs, dMiles, dKm;
    //input distance to a star in light years
    cout << "How far away is the star in light years?" <<endl;
    cin >> DLtYrs;
    //process calculate in miles and km
    dKm = DLtYrs * vc * cnv_m_km * cnv_sec_yr;
    //output the converted distances
    cout << "The distance to this star in km is ";
    cout << dKm <<endl;

    dMiles = dKm / cnv_m_km / cnv_ft_m / cnv_mi_ft;
    cout << "The distance to the star in miles is " <<endl;
    cout << dMiles <<endl;

    //exit stage right
    return 0;
}

