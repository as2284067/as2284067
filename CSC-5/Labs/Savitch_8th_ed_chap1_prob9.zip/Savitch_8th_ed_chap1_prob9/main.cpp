/*
 * Abel Salazar
 * January 7th, 2014
 * Savitch 8th edition chapter 1, problem 9
 */

#include <iostream>
using namespace std;

//system constants
const float gravity = 32.174;//units

//system functions 

int main(){
    
    float time, freefall;
    //input time
    cout << "Input the time in seconds" <<endl;
    cin >> time;
    //calculate the distance dropped
    freefall = gravity * time * time * 1/2;
    //output freefall
    cout << "The Distance Dropped = " << freefall << "(ft)" <<endl;
    //exit stage right
    return 0;
}